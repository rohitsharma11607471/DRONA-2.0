package com.example.drona.student;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;

public class Review extends AppCompatActivity {
    DatabaseHelper db;
    TextView review_id;
    TextView review_first_name;
    TextView review_last_name;
    TextView review_subject;
    AlertDialog.Builder confirm_dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
        android.support.v7.widget.Toolbar review;
        review=findViewById(R.id.review_toolbar);
        setSupportActionBar(review);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        db =new DatabaseHelper(this);
        Intent intent=getIntent();
        final String s=intent.getStringExtra("teacher_id");
        //Toast.makeText(this," "+s,Toast.LENGTH_LONG).show();
        final Cursor cursor =db.findTeacher(Integer.parseInt(s));

        review_id=findViewById(R.id.review_id);
        review_first_name =findViewById(R.id.review_firstname);
        review_last_name =findViewById(R.id.review_lastname);
        review_subject =findViewById(R.id.review_Subject);
        if(cursor.moveToFirst()) {
            //Toast.makeText(this, "hello " + cursor.getString(1), Toast.LENGTH_SHORT).show();
            review_id.setText(review_id.getText()+" "+cursor.getInt(0));
            review_first_name.setText(review_first_name.getText()+" "+cursor.getString(1));
            review_last_name.setText(review_last_name.getText()+" "+cursor.getString(2));
            review_subject.setText(review_subject.getText()+" "+cursor.getString(4));
        }
        final EditText editText=findViewById(R.id.review_texy_feild);
        final Button button=findViewById(R.id.review_button_submit);

        confirm_dialog=new AlertDialog.Builder(this);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //confirm_dialog.setTitle("CONFIRM");
                confirm_dialog.setCancelable(true);
                confirm_dialog.setMessage("Do you want to submit this review");

                confirm_dialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(editText.getText().toString().length()>0){
                            if(db.addreview(editText.getText().toString(),11607471,Integer.parseInt(s))==true)
                            {
                                Toast.makeText(Review.this, "Review Has been sent to your teacher :)", Toast.LENGTH_SHORT).show();

                            }}
                        else
                            Toast.makeText(Review.this, "Review cannot be left blank :(", Toast.LENGTH_SHORT).show();
                    }
                });
                confirm_dialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
               AlertDialog alert=confirm_dialog.create();
               alert.show();

            }
        });
    }
}
