package com.example.drona.finalLogin;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class SignupAdapter extends FragmentStatePagerAdapter {
    int nooftabs;
    public SignupAdapter(FragmentManager fm, int nooftabs)
    {
        super(fm);
        this.nooftabs=nooftabs;

    }
    @Override
    public Fragment getItem(int i) {
        if (i==0) {
            signup_student student = new signup_student();
            return student;
        }
        else
        {
            signupTeacher teacher=new signupTeacher();
            return teacher;

        }
    }

    @Override
    public int getCount() {
        return nooftabs;
    }


}
