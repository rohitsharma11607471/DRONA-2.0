package com.example.drona;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    public final static String DATABASE_NAME="RECORDS";
    public final static String STUDENTS_TABLE_NAME="STUDENTS";
    public final static String TEACHERS_TABLE_NAME="TEACHERS";
    public final static String REVIEW_TABLE="REVIEW";
    public final static String RATING_TABLE="RATING";
    // all the rows of students and teachers
    public final static String ID_ROW="ID";
    public final static String FIRSTNAME_ROW ="FIRSTNAME";
    public final static String LASTNAME_ROW="LASTNAME";
    public final static String PASSWORD_ROW="PASSWORD";
    //for the student
    public final static String SECTION_ROW="SECTION";
   //for the teacher
    public final static String SUBJECT_ROW="SUBJECT";

    //for the reviews
    public final static String REVIEWS_ROW="REVIEWS_ROW";
    public final static String REVIEW_BY="REVIEW_BY";
    public final static String REVIEW_TO="REVIEW_TO";
    public final static String TIME_STAMP="TIME_STAMP";

    // for the ratings
    public final static String RATING_ROW="RATING_ROW";
    public final static String RATING_BY="RATING_BY";
    public final static String RATING_TO="RATING_TO";


    public DatabaseHelper (Context context) {

        super(context,DATABASE_NAME,null,1 );
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
    db.execSQL("CREATE TABLE "+STUDENTS_TABLE_NAME+"(ID INTEGER PRIMARY KEY,FIRSTNAME TEXT,LASTNAME TEXT,PASSWORD TEXT,SECTION TEXT)");
    db.execSQL("CREATE TABLE "+TEACHERS_TABLE_NAME+"(ID INTEGER PRIMARY KEY,FIRSTNAME TEXT,LASTNAME TEXT,PASSWORD TEXT,SUBJECT TEXT)");
    db.execSQL("CREATE TABLE "+RATING_TABLE+"(RATING_ROW INTEGER,RATING_BY INTEGER,RATING_TO INTEGER)");
    db.execSQL("CREATE TABLE "+REVIEW_TABLE+"(REVIEW_ROW TEXT,REVIEW_BY INTEGER,REVIEW_TO INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    db.execSQL("DROP TABLE IF EXISTS "+STUDENTS_TABLE_NAME);
    db.execSQL("DROP TABLE IF EXISTS "+TEACHERS_TABLE_NAME);
    db.execSQL("DROP TABLE IF EXISTS "+RATING_TABLE);
    db.execSQL("DROP TABLE IF EXISTS "+REVIEW_TABLE);
        onCreate(db);
    }
    public Cursor allreviews(int teacherid)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM "+REVIEW_TABLE+" WHERE "+REVIEW_TO+" = '"+ teacherid +" ' ",null);
    }

    public Cursor allratings(int teacherid)
    {
        SQLiteDatabase db=this.getReadableDatabase();

        //Cursor cursor= db.rawQuery("SELECT * FROM "+RATING_TABLE,null);
        Cursor cursor= db.rawQuery("SELECT * FROM "+RATING_TABLE+" WHERE "+RATING_TO+" = '"+ teacherid +" ' ",null);
        return cursor;
    }
    public boolean addratings(int score,int r_from,int r_to)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("RATING_ROW",score);
        contentValues.put("RATING_BY",r_from);
        contentValues.put("RATING_TO",r_to);
        long x=db.insert(RATING_TABLE,null,contentValues);
        if(x==-1)
            return false;
        else
            return true;
    }

    public boolean addreview(String review,int r_from,int r_to)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("REVIEW_ROW",review);
        contentValues.put("REVIEW_BY",r_from);
        contentValues.put("REVIEW_TO",r_to);
        long x=db.insert(REVIEW_TABLE,null,contentValues);
        if(x==-1)
            return false;
        else
            return true;
    }
    public boolean authenticate(int username,String password,boolean isstudent)
    {
        SQLiteDatabase db=getWritableDatabase();
        String query;
        boolean flag=true;
        if(isstudent==true)
        {
            query="SELECT ID,PASSWORD FROM "+STUDENTS_TABLE_NAME+" WHERE ID="+username +" AND PASSWORD = "+password;

        }
        else
            {

                query="SELECT ID,PASSWORD FROM "+TEACHERS_TABLE_NAME+" WHERE ID="+username +" AND PASSWORD = "+password;
        }
        Cursor cursor;
        try {
             cursor = db.rawQuery(query, null);
            cursor.moveToFirst();
        }
        catch (SQLiteException s)
        {
            return false;
        }

       try {
          if(cursor.getCount()>0)
           {
               flag=true;
           }
           else
               flag=false;

       }
       catch (CursorIndexOutOfBoundsException c)
       {
           flag=false;
       }

        return flag;

    }
    public boolean insertdataastudent(int id,String firstname,String lastname,String password,String section)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(ID_ROW,id);
        contentValues.put(FIRSTNAME_ROW,firstname);
        contentValues.put(LASTNAME_ROW,lastname);
        contentValues.put(PASSWORD_ROW,password);
        contentValues.put(SECTION_ROW,section);
        long result=db.insert(STUDENTS_TABLE_NAME,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
        //db.close();
    }

    public Cursor findTeacher(int id)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        String query="SELECT * FROM "+TEACHERS_TABLE_NAME+" WHERE ID=' "+id+" '";
        Cursor cursor=db.rawQuery(query,null);
        return cursor;
    }

    public boolean insertdatateacher(int id,String firstname,String lastname,String password,String subject)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(ID_ROW,id);
        contentValues.put(FIRSTNAME_ROW,firstname);
        contentValues.put(LASTNAME_ROW,lastname);
        contentValues.put(PASSWORD_ROW,password);
        contentValues.put(SUBJECT_ROW,subject);
        long result=db.insert(TEACHERS_TABLE_NAME,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
        //db.close();
    }
    String sread=" ";
    public String readdata()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM "+TEACHERS_TABLE_NAME ,null);
        if(res.moveToFirst())
        {
            do{

                sread=sread+res.getInt(0)+" ";
                sread=sread+res.getString(1)+" ";
                sread=sread+" \n";

            }while (res.moveToNext());
        }
        return sread;
    }
    public Cursor allTeachers()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM "+TEACHERS_TABLE_NAME,null);

    }

}
