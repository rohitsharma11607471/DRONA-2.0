package com.example.drona.mentors;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;
import com.example.drona.student.Rate;
import com.example.drona.student.Review;

import java.util.ArrayList;

public class Mentors_review extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    DatabaseHelper teacherdatabase;
    String s;
    ListView listView;
    GridView gridView;
    ArrayList<Integer> ids;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        teacherdatabase=new DatabaseHelper(this);
        setContentView(R.layout.activity_mentors_review);
        Intent recieved=getIntent();
        String flag=recieved.getStringExtra("israte");
        Cursor mcursor=teacherdatabase.allTeachers();
        listView=findViewById(R.id.custom_list_view);
        //gridView=findViewById(R.id.custom_list_view);
        ids=new ArrayList<Integer>();
        final ArrayList<String> names=new ArrayList<String>();
        ArrayList<String> subject=new ArrayList<String>();

        Cursor c=teacherdatabase.allTeachers();
        if(c.moveToFirst())
        {
            do {
                ids.add(c.getInt(0));
                names.add(c.getString(1)+" "+c.getString(2));
                subject.add(c.getString(4));
            }while (c.moveToNext());
        }
        final Intent intent;
        intent=new Intent(Mentors_review.this, Review.class);
        // Toast.makeText(this, ""+ids, Toast.LENGTH_SHORT).show();
        CustomListAdapt myadapter=new CustomListAdapt(this,ids,names,subject);
        listView.setAdapter(myadapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               // Toast.makeText(getApplicationContext(),"you clicked on item number "+ids.get(position),Toast.LENGTH_SHORT).show();
                intent.putExtra("teacher_id",String.valueOf(ids.get(position)));
                startActivity(intent);

            }
        });
        }

}
