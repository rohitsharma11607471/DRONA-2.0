package com.example.drona.teachers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;

import com.example.drona.R;

import java.sql.Array;
import java.util.ArrayList;
import java.util.zip.Inflater;

public class Mentors_rate_adapter extends BaseAdapter {
    ArrayList<Integer> ratings;
    Context context;

    public Mentors_rate_adapter(Context context, ArrayList<Integer> ratings)
    {
        this.context=context;
        this.ratings=ratings;

    }
    @Override
    public int getCount() {
        return ratings.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view= LayoutInflater.from(context).inflate(R.layout.rate_adapter,parent,false);
        RatingBar ratingBar=view.findViewById(R.id.rate_adapter_stars);
        ratingBar.setMax(5);
        ratingBar.setRating(ratings.get(position));
        ratingBar.isInEditMode();
        return view;
    }
}
