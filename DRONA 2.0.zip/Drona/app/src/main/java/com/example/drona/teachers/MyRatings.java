package com.example.drona.teachers;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;
import com.example.drona.mentors.Customadapter;

import java.util.ArrayList;

public class MyRatings extends AppCompatActivity {
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_ratings);
        Intent intent=getIntent();
        ArrayList<Integer> myratings=new ArrayList<Integer>();
//        Toast.makeText(this,intent.getStringExtra("ID"),Toast.LENGTH_LONG).show();
        int id=Integer.parseInt(intent.getStringExtra("ID"));
        db=new DatabaseHelper(this);
        Cursor cursor=db.allratings(id);

        if(cursor.moveToFirst())
        {
            do {
               //Toast.makeText(this," "+cursor.getInt(0),Toast.LENGTH_LONG).show();
                myratings.add(cursor.getInt(0));
            }while (cursor.moveToNext());
        }
        double sum = 0;
        TextView totalrate=findViewById(R.id.totalrate);

        for(int i=0;i<myratings.size();i++)
        {
            sum+=myratings.get(i);
        }
        sum=(sum)/(myratings.size());
        if(sum>0)
        totalrate.setText(" "+String.format("%.2f",sum)+" /5");
        else
            totalrate.setText("0/5");

        ListView listView=findViewById(R.id.rating_listview);
        //ArrayAdapter<Integer> myadapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,myratings);
        Mentors_rate_adapter customadap=new Mentors_rate_adapter(this,myratings);
        listView.setAdapter(customadap);
    }

}
