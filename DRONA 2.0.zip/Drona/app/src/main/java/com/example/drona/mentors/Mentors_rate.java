package com.example.drona.mentors;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;
import com.example.drona.student.Rate;

import java.util.ArrayList;

public class Mentors_rate extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    DatabaseHelper teacherdatabase;

    ListView listView;
    ArrayList<Integer> ids;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        teacherdatabase=new DatabaseHelper(this);
        setContentView(R.layout.activity_mentors_rate);
        Intent mrecieved=getIntent();
        //tells us whether to rate or review
        Cursor mcursor=teacherdatabase.allTeachers();
        listView=findViewById(R.id.custom_list_view);
        ids=new ArrayList<Integer>();
        final ArrayList<String> names=new ArrayList<String>();
        ArrayList<String> subject=new ArrayList<String>();

        Cursor c=teacherdatabase.allTeachers();
        if(c.moveToFirst())
        {
            do {
                ids.add(c.getInt(0));
                names.add(c.getString(1)+" "+c.getString(2));
                subject.add(c.getString(4));
            }while (c.moveToNext());
        }
        final Intent intent;
        intent=new Intent(Mentors_rate.this, Rate.class);
        // Toast.makeText(this, ""+ids, Toast.LENGTH_SHORT).show();
        CustomListAdapt myadapter=new CustomListAdapt(this,ids,names,subject);
        listView.setAdapter(myadapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               // Toast.makeText(getApplicationContext(),"you clicked on item number "+ids.get(position),Toast.LENGTH_SHORT).show();
                intent.putExtra("teacher_id",String.valueOf(ids.get(position)));
                startActivity(intent);
            }
        });
        }

}
