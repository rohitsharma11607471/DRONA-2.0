package com.example.drona.finalLogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.drona.DatabaseHelper;
import com.example.drona.Tutorial;
import com.example.drona.teachers.MainActivityTeacher;
import com.example.drona.student.MainActivitystudent;
import com.example.drona.R;

public class FinalLogin extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private EditText mRegisteration;
    private EditText mPasswordView;
    private View mLoginFormView;
    private RadioButton student_teacher;
    private RadioButton student;
    Intent intent;
    boolean flag=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_login);
        databaseHelper=new DatabaseHelper(this);
        mRegisteration=findViewById(R.id.registration_number);
        mPasswordView=findViewById(R.id.password);
        Button signInButton=findViewById(R.id.email_sign_in_button);
        Button registerButton=findViewById(R.id.email_register_button);
        final RadioGroup logintype=findViewById(R.id.radiogroup);
        Button goToIntro=findViewById(R.id.gotointro);
        goToIntro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Tutorial.class));
            }
        });
        student=findViewById(R.id.student_radio);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRegisteration.getText().length() > 0) {
                    student_teacher = findViewById(logintype.getCheckedRadioButtonId());
    //Toast.makeText(getApplicationContext(),mRegisteration.getText(),Toast.LENGTH_SHORT).show();

                    if (student_teacher == student) {
                        if (databaseHelper.authenticate(Integer.parseInt(mRegisteration.getText().toString())
                                , mPasswordView.getText().toString(), true)) {
                           // Toast.makeText(getApplicationContext(), "Welcome "+mRegisteration.getText(), Toast.LENGTH_SHORT).show();
                            intent=new Intent(FinalLogin.this, MainActivitystudent.class);
                            intent.putExtra("ID",mRegisteration.getText().toString());
                            startActivity(intent);
                        } else
                            Toast.makeText(getApplicationContext(), "WRONG USERNAME OR PASSOWRD ", Toast.LENGTH_SHORT).show();

                    } else {
                        if (databaseHelper.authenticate(Integer.parseInt(mRegisteration.getText().toString())
                                , mPasswordView.getText().toString(), false)) {
                           // Toast.makeText(getApplicationContext(), "Welcome "+mRegisteration.getText(), Toast.LENGTH_SHORT).show();
                            intent=new Intent(FinalLogin.this, MainActivityTeacher.class);
                            intent.putExtra("ID",mRegisteration.getText().toString());
                            startActivity(intent);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "WRONG USERNAME OR PASSOWRD ", Toast.LENGTH_SHORT).show();

                        }

                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "INVALID INPUT", Toast.LENGTH_SHORT).show();

                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(FinalLogin.this, FinalRegister.class));
                 }
        });
    }


}
