package com.example.drona.finalLogin;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;

public class signup_student extends Fragment {

    private OnFragmentInteractionListener mListener;

    public signup_student() {
        // Required empty public constructor
    }

    private EditText student_id;
    private EditText firstname;
    private EditText lastname;
    private EditText password;
    private EditText section;
     private int id;
    private Button student_register;
    DatabaseHelper studentDatabase;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_signup_student, container, false);

        student_id = v.findViewById(R.id.sstudent_registation_signup);
        firstname = v.findViewById(R.id.student_first_name_signup);
        lastname = v.findViewById(R.id.student_last_name_signup);
        password = v.findViewById(R.id.student_passowrd_signup);
        section = v.findViewById(R.id.student_section_signup);
        student_register=v.findViewById(R.id.register_student);
        student_register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if((student_id.getText().toString().length()>7&&student_id.getText().toString().length()<10)&&(password.getText().length()>0)) {
//                Toast.makeText(getActivity(),"you just clicked", Toast.LENGTH_SHORT).show();
                    if (studentDatabase.insertdataastudent
                            (Integer.parseInt(student_id.getText().toString()), firstname.getText().toString(), lastname.getText().toString(), password.getText().toString()
                                    , section.getText().toString()) == true) {
                        Toast.makeText(getActivity(), "CONGRATS YOU HAVE BEEN REGISTERED", Toast.LENGTH_SHORT).show();

                    }
                    else
                        Toast.makeText(getActivity(), "USER ALREADY EXISTS", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getActivity(), "REGISTRATION NUMBER IS INVALID(SHOULD 8 DIGITS)", Toast.LENGTH_SHORT).show();

            }
        });

        // Inflate the layout for this fragment
        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        studentDatabase=new DatabaseHelper(context);
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
