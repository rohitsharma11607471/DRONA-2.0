package com.example.drona.teachers;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.drona.R;
import com.example.drona.finalLogin.FinalLogin;
import com.example.drona.student.Rate;

public class MainActivityTeacher extends AppCompatActivity {
    Button ratings;
    Button reviews;
    Intent recieved;
    Button logout;
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_teacher);
        recieved=getIntent();
        s="Student";
        s=recieved.getStringExtra("ID");
        logout=findViewById(R.id.logout_button);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivityTeacher.this, FinalLogin.class);
                startActivity(intent);
            }
        });
        TextView teachername=findViewById(R.id.teacher_main_id);
        if(s!=null)
            teachername.setText("HELLO "+s);
        ratings=findViewById(R.id.view_ratings);
        reviews=findViewById(R.id.view_reviews);

        final Intent rateIntent=new Intent(getApplicationContext(),MyRatings.class);
        ratings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rateIntent.putExtra("ID",s);
                startActivity(rateIntent);
            }
        });
        final Intent reviewIntent=new Intent(getApplicationContext(),MyReviews.class);
        reviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reviewIntent.putExtra("ID",s);
                startActivity(reviewIntent);

            }
        });
    }
}
