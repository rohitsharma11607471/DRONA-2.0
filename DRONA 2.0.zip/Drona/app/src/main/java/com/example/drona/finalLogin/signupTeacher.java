package com.example.drona.finalLogin;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.drona.DatabaseHelper;
import com.example.drona.student.MainActivitystudent;
import com.example.drona.R;


public class signupTeacher extends Fragment {
     private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

   private String mParam1;
    private String mParam2;

    DatabaseHelper teachersdata;
    private OnFragmentInteractionListener mListener;

    public signupTeacher() {
        // Required empty public constructor
    }

    public static signupTeacher newInstance(String param1, String param2) {
        signupTeacher fragment = new signupTeacher();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    Button teacher;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_signup_teacher, container, false);
        teacher=v.findViewById(R.id.teacher_register);
        final EditText teacher_id=v.findViewById(R.id.teacher_registation_signup);
        final EditText firstname=v.findViewById(R.id.teahcer_first_name_signup);
        final EditText lastname=v.findViewById(R.id.teahcer_last_name_signup);
        final EditText password=v.findViewById(R.id.teacher_passowrd_signup);
        final EditText subject=v.findViewById(R.id.teacher_subject_signup);
        teacher.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //startActivity(new Intent(getActivity(), MainActivitystudent.class));
                if(((teacher_id.getText().toString().length()>5)&&teacher_id.getText().toString().length()<9)&&(password.getText().length()>0)) {
                    if (teachersdata.insertdatateacher
                            (Integer.parseInt(teacher_id.getText().toString()), firstname.getText().toString(), lastname.getText().toString(), password.getText().toString()
                                    , subject.getText().toString()) == true)
                        Toast.makeText(getActivity(), "CONGRATS YOU HAVE BEEN REGISTERED", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getActivity(), "USER ALREADY EXISTS", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getActivity(), "REGISTRATION NUMBER IS INVALID(SHOULD more than 5 DIGITS)", Toast.LENGTH_SHORT).show();



            }
        });


        return v;
    }

     public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
         teachersdata=new DatabaseHelper(context);
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
