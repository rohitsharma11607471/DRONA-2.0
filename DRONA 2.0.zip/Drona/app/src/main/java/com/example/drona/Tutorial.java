package com.example.drona;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.drona.finalLogin.FinalLogin;


public class Tutorial extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    private ViewPager tutoial_slides;
    private LinearLayout dots;
    private TextView[] mdots;
    private Button skip_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);
        tutoial_slides=findViewById(R.id.tutorial_viewpager);
        dots=findViewById(R.id.tutorial_dots);
        addcountdots(4,0);
        tutoial_slides.addOnPageChangeListener(viewpager);
        tutoial_slides.setAdapter(new viewpager_adapter(this));
        skip_button=findViewById(R.id.tutorial_skip);
        skip_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                sharedPreferences= (SharedPreferences) getApplicationContext().getSharedPreferences("CHECK_LOGIN_SIGNUP",0);
//                SharedPreferences.Editor editor=sharedPreferences.edit();
//                editor.putBoolean("FLAG",true);
//                editor.commit();

                  Intent gotomain=new Intent(Tutorial.this, FinalLogin.class);
                startActivity(gotomain);
            }
        });
    }
    public void addcountdots(int n,int pos){
        mdots=new TextView[n];
        dots.removeAllViews();
        for( int i=0;i<mdots.length;i++)
        {
            mdots[i]=new TextView(this);
            mdots[i].setText(Html.fromHtml("&#8226;"));
            mdots[i].setTextSize(38);
            mdots[i].setTextColor(getResources().getColor(R.color.backgroundcolor));
            dots.addView(mdots[i]);
        }
        if(mdots.length>0)
        {
            mdots[pos].setTextColor(getResources().getColor(R.color.colorPrimary));
        }
    }
    ViewPager.OnPageChangeListener viewpager =new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int i, float v, int i1) {

        }

        @Override
        public void onPageSelected(int i) {
            addcountdots(4,i);
            if(i==(mdots.length-1))
            {
                skip_button.setText("Log In");
            }
        }

        @Override
        public void onPageScrollStateChanged(int i) {

        }
    };
}
