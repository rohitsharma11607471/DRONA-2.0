package com.example.drona.teachers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.drona.R;

import java.util.ArrayList;

public class Mentors_review_adapter extends BaseAdapter {
    ArrayList<String> reviews;
    Context context;

    public Mentors_review_adapter(Context context, ArrayList<String> ratings)
    {
        this.context=context;
        this.reviews=ratings;

    }
    @Override
    public int getCount() {
        return reviews.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view= LayoutInflater.from(context).inflate(R.layout.review_adapter,parent,false);
        TextView review=view.findViewById(R.id.review_adapter_text);
        review.setText(reviews.get(position));
        return view;
    }
}
