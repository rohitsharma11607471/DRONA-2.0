package com.example.drona.mentors;

import android.content.Context;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.drona.R;

public class Customadapter extends RecyclerView.Adapter<Customadapter.Customviewholder> {
    private Context context;
    private Cursor cursor;

    Customadapter(Context context, Cursor cursor){

        this.context=context;
        this.cursor=cursor;
    }
    public class Customviewholder extends RecyclerView.ViewHolder
    {
        public TextView nameText;
        public TextView subjectText;


        public Customviewholder(@NonNull View itemView) {
            super(itemView);
            nameText=itemView.findViewById(R.id.template_teacher_name);
            subjectText=itemView.findViewById(R.id.template_teacher_subject);

        }
    }

    @NonNull
    @Override
    public Customviewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.template_cursor_view,viewGroup,false);
        return new Customviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Customviewholder customviewholder, int i) {

        if(!cursor.move(i))
        {
            return;
        }
        String name=cursor.getString(cursor.getColumnIndex("FIRSTNAME"));
        String subject =cursor.getString(cursor.getColumnIndex("LASTNAME"));
        customviewholder.nameText.setText(name);
        customviewholder.subjectText.setText(subject);

    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }
}
