package com.example.drona.mentors;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.drona.R;

import java.util.ArrayList;

public class CustomListAdapt extends BaseAdapter {
    Context context;
    ArrayList<Integer> id;
    ArrayList<String> names;
    ArrayList<String> subject;
    int count;

    CustomListAdapt(Context context, ArrayList<Integer> id,ArrayList<String> names,ArrayList<String> subject)
    {
        this.context=context;
        this.id=id;
        this.names=names;
        this.subject=subject;
        this.count=id.size();
    }
    @Override
    public int getCount() {
        return count;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView=LayoutInflater.from(context).inflate(R.layout.template_cursor_view,null);
        TextView teacherid=convertView.findViewById(R.id.template_teacher_id);
        TextView teachername=convertView.findViewById(R.id.template_teacher_name);
        TextView subjectname=convertView.findViewById(R.id.template_teacher_subject);
        teacherid.setText(""+id.get(position));
        teachername.setText(names.get(position));
        subjectname.setText(subject.get(position));
        return convertView;
    }
}
