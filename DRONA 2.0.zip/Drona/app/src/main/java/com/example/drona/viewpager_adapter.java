package com.example.drona;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class viewpager_adapter extends PagerAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    viewpager_adapter(Context context)
    {
        this.context=context;

    }
    private String headings[]={"Make Classrooms Interactive","Rate your Teachers","Anonoums Feedbacks","Help Your Teacheers Improve"};
    private int images[]={R.drawable.tutorial_student_1,R.drawable.rate,R.drawable.feedbacks,R.drawable.improve};
    private String data[]={"Break the Bounds of conventional Classrooms","Ratings and reviews helps your teachers to analyse and improve","Submit your feedbacks anonymously","avoid bad language , as that could get you banned"};

    @Override
    public int getCount() {
        return headings.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view==(RelativeLayout)o;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
            layoutInflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            View view=layoutInflater.inflate(R.layout.tutorial_slides,container,false);
             TextView mheading=view.findViewById(R.id.tutorial_heading);
        ImageView mimage=view.findViewById(R.id.tutoial_image);
        TextView mdata=view.findViewById(R.id.tutorial_data);
        mheading.setText(headings[position]);
        mimage.setImageResource(images[position]);
        mdata.setText(data[position]);
        container.addView(view);
            return view;

    }
    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout)object);
    }

}
