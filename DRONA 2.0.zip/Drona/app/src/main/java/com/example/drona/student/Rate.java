package com.example.drona.student;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;

import java.util.ArrayList;

public class Rate extends AppCompatActivity {
    RelativeLayout relativeLayout;

    DatabaseHelper db;
    Toolbar rate_toolbar;
    TextView rate_id;
    TextView rate_first_name;
    TextView rate_last_name;
    TextView rate_subject;
    AlertDialog.Builder confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);
        Intent intent=getIntent();
        db=new DatabaseHelper(this);
        rate_toolbar=findViewById(R.id.rate_toolbar);
        setSupportActionBar(rate_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        final String s=intent.getStringExtra("teacher_id");
        relativeLayout=findViewById(R.id.rate_relative_layout);
        final Cursor cursor =db.findTeacher(Integer.parseInt(s));
        rate_id=findViewById(R.id.rate_id);
        rate_first_name=findViewById(R.id.rate_firstname);
        rate_last_name=findViewById(R.id.rate_lastname);
        rate_subject=findViewById(R.id.rate_Subject);
        if(cursor.moveToFirst()) {
            //Toast.makeText(this, "hello " + cursor.getString(1), Toast.LENGTH_SHORT).show();
            rate_id.setText(rate_id.getText()+" "+cursor.getInt(0));
            rate_first_name.setText(rate_first_name.getText()+" "+cursor.getString(1));
            rate_last_name.setText(rate_last_name.getText()+" "+cursor.getString(2));
            rate_subject.setText(rate_subject.getText()+" "+cursor.getString(4));
        }
            final RatingBar ratingBar=findViewById(R.id.ratingbar);
        ratingBar.setMax(5);
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
//                Toast.makeText(getApplicationContext(),,Toast.LENGTH_SHORT).show();
                Snackbar snackbar=Snackbar.make(relativeLayout,"You have chosen "+cursor.getString(1)+" "+ratingBar.getRating(),Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(getResources().getColor(R.color.green));
                snackbar.show();

            }
        });
        Button rate=findViewById(R.id.rate_submit);
        confirm=new AlertDialog.Builder(this);
        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirm.setTitle("CONFIRM");
                confirm.setMessage("DO YOU WANT TO SUBMIT THIS RATING?");
                confirm.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Snackbar snackbar;
                        if(db.addratings(((int)ratingBar.getRating()),11607471,Integer.parseInt(s))==true)
                        { snackbar=Snackbar.make(relativeLayout,"You rated "+cursor.getString(1)+" "+ratingBar.getRating(),Snackbar.LENGTH_LONG);
                            snackbar.setActionTextColor(getResources().getColor(R.color.green));
                            snackbar.show();

                        }


                    }
                });
                confirm.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog dialog=confirm.create();
                dialog.show();


            }
        });
    }
}
