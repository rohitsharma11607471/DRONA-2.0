package com.example.drona.teachers;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.drona.DatabaseHelper;
import com.example.drona.R;

import java.util.ArrayList;

public class MyReviews extends AppCompatActivity {
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_reviews);
        Intent intent=getIntent();
        ArrayList<String> myreviews=new ArrayList<String>();

        //Toast.makeText(this,intent.getStringExtra("ID"),Toast.LENGTH_LONG).show();
        int id=Integer.parseInt(intent.getStringExtra("ID"));
        db=new DatabaseHelper(this);
        Cursor cursor=db.allreviews(id);
        if(cursor.moveToFirst())
        {
            do {
                    myreviews.add(cursor.getString(0));
            }while (cursor.moveToNext());
        }
        ListView listView=findViewById(R.id.review_listview);
       // ArrayAdapter<String> myadapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,myreviews);
        Mentors_review_adapter customadap=new Mentors_review_adapter(this,myreviews);

        listView.setAdapter(customadap);



    }
}
